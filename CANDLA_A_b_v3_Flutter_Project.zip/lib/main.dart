import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const CandlaApp());

const rose = Color(0xFFE8A1B5);
const darkRose = Color(0xFF9B4965);
const bg = Color(0xFFFFF7FA);

class CandlaApp extends StatelessWidget {
  const CandlaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'CANDLA.A.b',
    theme: ThemeData(
      useMaterial3: true, scaffoldBackgroundColor: bg,
      colorScheme: ColorScheme.fromSeed(seedColor: rose, brightness: Brightness.light),
      appBarTheme: const AppBarTheme(backgroundColor: bg, foregroundColor: darkRose),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
      ),
    ),
    home: const HomePage(),
  );
}

class Order {
  String customer, product, status, notes;
  int qty;
  double price;
  DateTime date;
  Order({required this.customer, required this.product, required this.qty, required this.price,
    required this.status, required this.date, this.notes = ''});
  double get total => qty * price;
  Map<String,dynamic> toJson()=>{'customer':customer,'product':product,'qty':qty,'price':price,
    'status':status,'date':date.toIso8601String(),'notes':notes};
  factory Order.fromJson(Map j)=>Order(customer:j['customer'],product:j['product'],qty:j['qty'],
    price:(j['price'] as num).toDouble(),status:j['status'],date:DateTime.parse(j['date']),notes:j['notes']??'');
}
class MaterialItem {
  String name, unit;
  double stock, cost, minimum;
  MaterialItem(this.name,this.stock,this.unit,this.cost,this.minimum);
  Map<String,dynamic> toJson()=>{'name':name,'stock':stock,'unit':unit,'cost':cost,'minimum':minimum};
  factory MaterialItem.fromJson(Map j)=>MaterialItem(j['name'],(j['stock'] as num).toDouble(),
    j['unit'],(j['cost'] as num).toDouble(),(j['minimum'] as num).toDouble());
}
class RecipeLine {
  String material;
  double amount;
  RecipeLine(this.material,this.amount);
  Map<String,dynamic> toJson()=>{'material':material,'amount':amount};
  factory RecipeLine.fromJson(Map j)=>RecipeLine(j['material'],(j['amount'] as num).toDouble());
}
class Expense {
  String title;
  double amount;
  DateTime date;
  Expense(this.title,this.amount,this.date);
  Map<String,dynamic> toJson()=>{'title':title,'amount':amount,'date':date.toIso8601String()};
  factory Expense.fromJson(Map j)=>Expense(j['title'],(j['amount'] as num).toDouble(),DateTime.parse(j['date']));
}

class Store extends ChangeNotifier {
  List<Order> orders=[];
  List<MaterialItem> materials=[];
  List<RecipeLine> recipe=[];
  List<Expense> expenses=[];
  bool ready=false;
  Future<void> load() async {
    final p=await SharedPreferences.getInstance();
    List decode(String k)=>jsonDecode(p.getString(k)??'[]') as List;
    try {
      orders=decode('orders').map((e)=>Order.fromJson(e)).toList();
      materials=decode('materials').map((e)=>MaterialItem.fromJson(e)).toList();
      recipe=decode('recipe').map((e)=>RecipeLine.fromJson(e)).toList();
      expenses=decode('expenses').map((e)=>Expense.fromJson(e)).toList();
    } catch (_) {}
    ready=true; notifyListeners();
  }
  Future<void> save() async {
    final p=await SharedPreferences.getInstance();
    await p.setString('orders',jsonEncode(orders.map((e)=>e.toJson()).toList()));
    await p.setString('materials',jsonEncode(materials.map((e)=>e.toJson()).toList()));
    await p.setString('recipe',jsonEncode(recipe.map((e)=>e.toJson()).toList()));
    await p.setString('expenses',jsonEncode(expenses.map((e)=>e.toJson()).toList()));
    notifyListeners();
  }
  double get sales=>orders.fold(0,(s,o)=>s+o.total);
  double get expenseTotal=>expenses.fold(0,(s,e)=>s+e.amount);
  double get productionCost=>orders.fold(0,(sum,o)=>sum+unitCost*o.qty);
  double get unitCost=>recipe.fold(0,(sum,r){
    final m=materials.where((x)=>x.name==r.material);
    return sum+(m.isEmpty?0:m.first.cost*r.amount);
  });
  double get net=>sales-expenseTotal-productionCost;
  int get customers=>orders.map((o)=>o.customer.trim().toLowerCase()).toSet().length;
  void addOrder(Order o) {
    // تخصم وصفة المواد المحددة عند تسجيل الطلبية، حسب عدد القطع.
    for(final line in recipe) {
      final matches=materials.where((m)=>m.name==line.material);
      if(matches.isNotEmpty) matches.first.stock-=line.amount*o.qty;
    }
    orders.add(o);
  }
}

final store=Store();

class HomePage extends StatefulWidget { const HomePage({super.key}); @override State<HomePage> createState()=>_HomePageState(); }
class _HomePageState extends State<HomePage> {
  int tab=0;
  @override void initState(){super.initState();store.addListener(_refresh);store.load();}
  void _refresh(){if(mounted)setState((){});}
  @override void dispose(){store.removeListener(_refresh);super.dispose();}
  @override Widget build(BuildContext context) {
    final pages=[const Dashboard(),const OrdersPage(),const MaterialsPage(),const RecipePage(),const ExpensesPage(),const CustomersPage()];
    return Scaffold(
      appBar: AppBar(title: const Text('CANDLA.A.b 💗',style: TextStyle(fontWeight:FontWeight.bold)),
        actions:[IconButton(onPressed:()=>showAboutDialog(context:context,applicationName:'CANDLA.A.b',applicationVersion:'3.0.0',children:[const Text('إدارة الطلبيات والمخزون وتكلفة إنتاج الشموع.')]),icon:const Icon(Icons.info_outline))]),
      body: store.ready?pages[tab]:const Center(child:CircularProgressIndicator()),
      bottomNavigationBar: NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),
        destinations: const [
          NavigationDestination(icon:Icon(Icons.dashboard_outlined),label:'الرئيسية'),
          NavigationDestination(icon:Icon(Icons.receipt_long),label:'الطلبيات'),
          NavigationDestination(icon:Icon(Icons.inventory_2_outlined),label:'المخزون'),
          NavigationDestination(icon:Icon(Icons.science_outlined),label:'الوصفة'),
          NavigationDestination(icon:Icon(Icons.payments_outlined),label:'المصاريف'),
          NavigationDestination(icon:Icon(Icons.people_outline),label:'الزبائن'),
        ]),
    );
  }
}

String money(double n)=>'${n.toStringAsFixed(2)} دج';
Widget panel(String title,Widget child)=>Card(color:Colors.white,margin:const EdgeInsets.symmetric(vertical:7),
  child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Text(title,style:const TextStyle(fontWeight:FontWeight.bold,color:darkRose,fontSize:16)),const SizedBox(height:9),child])));
Widget metric(String label,String value,IconData icon)=>Expanded(child:Card(color:Colors.white,child:Padding(padding:const EdgeInsets.all(12),
  child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(icon,color:darkRose),const SizedBox(height:7),
    Text(value,style:const TextStyle(fontWeight:FontWeight.bold,fontSize:16)),Text(label,style:const TextStyle(color:Colors.black54,fontSize:12))]))));

class Dashboard extends StatelessWidget { const Dashboard({super.key});
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(14),children:[
    const Text('ملخص مشروعك',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold,color:darkRose)),
    Row(children:[metric('الطلبيات','${store.orders.length}',Icons.shopping_bag_outlined),metric('الزبائن','${store.customers}',Icons.people)]),
    Row(children:[metric('المبيعات',money(store.sales),Icons.trending_up),metric('تكلفة المواد',money(store.productionCost),Icons.factory_outlined)]),
    Row(children:[metric('المصاريف',money(store.expenseTotal),Icons.money_off),metric('الصافي التقديري',money(store.net),Icons.account_balance_wallet)]),
    panel('تنبيهات المخزون',store.materials.where((m)=>m.stock<=m.minimum).isEmpty
      ?const Text('لا توجد مواد تحت الحد الأدنى.')
      :Column(children:store.materials.where((m)=>m.stock<=m.minimum).map((m)=>ListTile(dense:true,leading:const Icon(Icons.warning_amber,color:Colors.deepOrange),title:Text(m.name),subtitle:Text('المتبقي ${m.stock} ${m.unit}')).toList())),
    panel('تكلفة الوصفة الحالية',Text('تكلفة المواد لكل شمعة حسب الوصفة: ${money(store.unitCost)}')),
    panel('ملاحظة محاسبية',const Text('الصافي التقديري = المبيعات − المصاريف المسجلة − تكلفة المواد المحسوبة من الوصفة. لا يشمل التكاليف غير المسجلة مثل التغليف أو الكهرباء إلا إذا أضفتها ضمن الوصفة أو المصاريف.')),
  ]);
}

Future<String?> askText(BuildContext c,String title,{String initial=''}) async {
  final ctrl=TextEditingController(text:initial);
  return showDialog<String>(context:c,builder:(ctx)=>AlertDialog(title:Text(title),content:TextField(controller:ctrl,autofocus:true,decoration:const InputDecoration(hintText:'اكتب هنا')),
    actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(ctx,ctrl.text.trim()),child:const Text('حفظ'))]));
}
Future<double?> askNumber(BuildContext c,String title,{double initial=0}) async {
  final ctrl=TextEditingController(text:initial==0?'':initial.toString());
  return showDialog<double>(context:c,builder:(ctx)=>AlertDialog(title:Text(title),content:TextField(controller:ctrl,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(hintText:'0.00')),
    actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(ctx,double.tryParse(ctrl.text.replaceAll(',','.'))),child:const Text('حفظ'))]));
}
Future<void> addOrderDialog(BuildContext c) async {
  final name=TextEditingController(), product=TextEditingController(), qty=TextEditingController(text:'1'), price=TextEditingController();
  await showDialog(context:c,builder:(ctx)=>AlertDialog(title:const Text('طلبية جديدة'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
    TextField(controller:name,decoration:const InputDecoration(labelText:'اسم الزبون')),
    TextField(controller:product,decoration:const InputDecoration(labelText:'نوع الشمعة / المنتج')),
    TextField(controller:qty,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'الكمية')),
    TextField(controller:price,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'سعر القطعة (دج)')),
  ])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('إلغاء')),FilledButton(onPressed:(){
    final q=int.tryParse(qty.text)??0, p=double.tryParse(price.text.replaceAll(',','.'))??-1;
    if(name.text.trim().isEmpty||product.text.trim().isEmpty||q<1||p<0)return;
    store.addOrder(Order(customer:name.text.trim(),product:product.text.trim(),qty:q,price:p,status:'جديدة',date:DateTime.now()));
    store.save();Navigator.pop(ctx);
  },child:const Text('إضافة'))])); 
}

class OrdersPage extends StatelessWidget { const OrdersPage({super.key});
 @override Widget build(BuildContext context)=>Scaffold(backgroundColor:bg,floatingActionButton:FloatingActionButton.extended(backgroundColor:darkRose,foregroundColor:Colors.white,onPressed:()=>addOrderDialog(context),icon:const Icon(Icons.add),label:const Text('طلبية جديدة')),
 body:store.orders.isEmpty?const Center(child:Text('لا توجد طلبيات بعد')):ListView.builder(padding:const EdgeInsets.all(12),itemCount:store.orders.length,itemBuilder:(c,i){
  final o=store.orders[i];return Card(color:Colors.white,child:ListTile(title:Text('${o.customer} — ${o.product}',style:const TextStyle(fontWeight:FontWeight.bold)),
   subtitle:Text('${o.qty} × ${money(o.price)} = ${money(o.total)}\\n${o.date.day}/${o.date.month}/${o.date.year}'),
   isThreeLine:true,trailing:PopupMenuButton<String>(onSelected:(v){if(v=='delete'){store.orders.removeAt(i);}else{o.status=v;}store.save();},
    itemBuilder:(_)=>['جديدة','قيد التحضير','جاهزة','تم التسليم','delete'].map((s)=>PopupMenuItem(value:s,child:Text(s=='delete'?'حذف':s))).toList()),
   leading:const Icon(Icons.local_cafe_outlined,color:darkRose)));
 }));
}

class MaterialsPage extends StatelessWidget { const MaterialsPage({super.key});
 Future<void> add(BuildContext c) async {
  final n=await askText(c,'اسم المادة');if(n==null||n.isEmpty)return;
  final q=await askNumber(c,'الكمية الحالية');if(q==null)return;
  final unit=await askText(c,'وحدة القياس (غ، كغ، قطعة، مل)')??'وحدة';
  final cost=await askNumber(c,'تكلفة وحدة القياس بالدينار')??0;
  final min=await askNumber(c,'حد التنبيه الأدنى')??0;
  store.materials.add(MaterialItem(n,q,unit,cost,min));store.save();
 }
 @override Widget build(BuildContext context)=>Scaffold(backgroundColor:bg,floatingActionButton:FloatingActionButton(onPressed:()=>add(context),backgroundColor:darkRose,foregroundColor:Colors.white,child:const Icon(Icons.add)),
 body:store.materials.isEmpty?const Center(child:Text('أضف الشمع، العطور، الألوان، الفتائل والتغليف')):ListView(padding:const EdgeInsets.all(12),children:store.materials.map((m)=>Card(color:Colors.white,child:ListTile(
  title:Text(m.name),subtitle:Text('الكمية: ${m.stock} ${m.unit} • تكلفة الوحدة: ${money(m.cost)} • تنبيه عند: ${m.minimum}'),
  leading:Icon(m.stock<=m.minimum?Icons.warning_amber:Icons.inventory,color:m.stock<=m.minimum?Colors.deepOrange:darkRose),
  trailing:PopupMenuButton<String>(onSelected:(v)async{if(v=='delete'){store.materials.remove(m);}else{final delta=await askNumber(context,'كمية التعديل (+ إضافة / - استهلاك)');if(delta!=null)m.stock+=delta;}store.save();},
   itemBuilder:(_)=>const [PopupMenuItem(value:'adjust',child:Text('تعديل الكمية')),PopupMenuItem(value:'delete',child:Text('حذف'))])))).toList()));
 }
}

class RecipePage extends StatelessWidget { const RecipePage({super.key});
 Future<void> add(BuildContext c) async {
  if(store.materials.isEmpty){ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content:Text('أضف مواد المخزون أولاً')));return;}
  String selected=store.materials.first.name;
  final amount=TextEditingController(text:'1');
  await showDialog(context:c,builder:(ctx)=>AlertDialog(title:const Text('إضافة مادة للوصفة'),content:Column(mainAxisSize:MainAxisSize.min,children:[
   StatefulBuilder(builder:(ctx,set)=>DropdownButtonFormField<String>(value:selected,items:store.materials.map((m)=>DropdownMenuItem(value:m.name,child:Text(m.name))).toList(),onChanged:(v)=>set(()=>selected=v!),decoration:const InputDecoration(labelText:'المادة')),
   TextField(controller:amount,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'الكمية اللازمة لشمعة واحدة')),
  ]),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('إلغاء')),FilledButton(onPressed:(){final a=double.tryParse(amount.text.replaceAll(',','.'))??0;if(a>0){store.recipe.removeWhere((r)=>r.material==selected);store.recipe.add(RecipeLine(selected,a));store.save();}Navigator.pop(ctx);},child:const Text('حفظ'))]));
 }
 @override Widget build(BuildContext context)=>Scaffold(backgroundColor:bg,floatingActionButton:FloatingActionButton.extended(onPressed:()=>add(context),backgroundColor:darkRose,foregroundColor:Colors.white,icon:const Icon(Icons.add),label:const Text('مادة للوصفة')),
 body:ListView(padding:const EdgeInsets.all(14),children:[
  panel('طريقة العمل',const Text('حدد كمية كل مادة تحتاجها لصناعة شمعة واحدة. عند تسجيل طلبية جديدة، يخصم التطبيق تلقائياً الكمية المحددة مضروبة في عدد الشموع من المخزون.')),
  panel('تكلفة المواد للشمعة الواحدة',Text(money(store.unitCost))),
  ...store.recipe.map((r)=>Card(color:Colors.white,child:ListTile(title:Text(r.material),subtitle:Text('الكمية لكل شمعة: ${r.amount}'),trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:(){store.recipe.remove(r);store.save();}))),
  if(store.recipe.isEmpty)const Padding(padding:EdgeInsets.all(16),child:Text('لم تضف وصفة بعد.')),
 ]);
 }
}

class ExpensesPage extends StatelessWidget { const ExpensesPage({super.key});
 Future<void> add(BuildContext c) async {final title=await askText(c,'اسم المصروف');if(title==null||title.isEmpty)return;final a=await askNumber(c,'المبلغ بالدينار');if(a==null||a<=0)return;store.expenses.add(Expense(title,a,DateTime.now()));store.save();}
 @override Widget build(BuildContext context)=>Scaffold(backgroundColor:bg,floatingActionButton:FloatingActionButton(onPressed:()=>add(context),backgroundColor:darkRose,foregroundColor:Colors.white,child:const Icon(Icons.add)),
 body:store.expenses.isEmpty?const Center(child:Text('لا توجد مصاريف مسجلة')):ListView(padding:const EdgeInsets.all(12),children:store.expenses.map((e)=>Card(color:Colors.white,child:ListTile(title:Text(e.title),subtitle:Text('${e.date.day}/${e.date.month}/${e.date.year}'),trailing:Text(money(e.amount),style:const TextStyle(fontWeight:FontWeight.bold)),leading:IconButton(icon:const Icon(Icons.delete_outline),onPressed:(){store.expenses.remove(e);store.save();}))).toList()));
 }
}

class CustomersPage extends StatelessWidget { const CustomersPage({super.key});
 @override Widget build(BuildContext context) {
  final map=<String,List<Order>>{};
  for(final o in store.orders){map.putIfAbsent(o.customer,()=>[]).add(o);}
  final entries=map.entries.toList()..sort((a,b)=>b.value.length.compareTo(a.value.length));
  return ListView(padding:const EdgeInsets.all(12),children:[
   panel('أفضل الزبائن حسب عدد الطلبيات',const Text('الترتيب تنازلياً حسب عدد الطلبيات المسجلة.')),
   ...entries.asMap().entries.map((e)=>Card(color:Colors.white,child:ListTile(
    leading:CircleAvatar(backgroundColor:rose,child:Text('${e.key+1}')),
    title:Text(e.value.key),subtitle:Text('${e.value.value.length} طلبية'),
    trailing:Text(money(e.value.value.fold(0,(s,o)=>s+o.total)),style:const TextStyle(fontWeight:FontWeight.bold)),
   ))),
   if(entries.isEmpty)const Center(child:Text('ستظهر قائمة الزبائن بعد إضافة الطلبيات')),
  ]);
 }
}
